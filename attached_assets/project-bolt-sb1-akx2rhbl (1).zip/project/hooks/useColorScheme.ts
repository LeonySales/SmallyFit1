import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const THEME_KEY = '@theme_preference';

export function useColorScheme() {
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    loadThemePreference();
  }, []);

  const loadThemePreference = async () => {
    try {
      const savedTheme = await AsyncStorage.getItem(THEME_KEY);
      setIsDarkMode(savedTheme === 'dark');
    } catch (error) {
      console.error('Error loading theme preference:', error);
    }
  };

  const toggleColorScheme = async () => {
    try {
      const newMode = !isDarkMode;
      await AsyncStorage.setItem(THEME_KEY, newMode ? 'dark' : 'light');
      setIsDarkMode(newMode);
    } catch (error) {
      console.error('Error saving theme preference:', error);
    }
  };

  return { isDarkMode, toggleColorScheme };
}