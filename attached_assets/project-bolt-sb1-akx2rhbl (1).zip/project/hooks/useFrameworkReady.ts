import { useEffect } from 'react';

declare global {
  interface Window {
    frameworkReady?: () => void;
  }
}

export function useFrameworkReady() {
  useEffect(() => {
    let mounted = true;

    if (mounted) {
      window.frameworkReady?.();
    }

    return () => {
      mounted = false;
    };
  }, []);
}