export const COLORS = {
  primary: '#34E084', // Main green
  primaryDark: '#2AB76A',
  primaryLight: '#5EE8A1',
  
  secondary: '#6CB9F0', // Blue for accents
  secondaryDark: '#4A97D8',
  secondaryLight: '#91D0FF',
  
  accent: '#FFB347', // Orange for highlights
  accentDark: '#FF9400',
  accentLight: '#FFD27F',
  
  success: '#4CAF50',
  warning: '#FFC107',
  error: '#F44336',
  
  background: '#F7FAFC',
  darkBackground: '#121212',
  darkSurface: '#1E1E1E',
  
  card: '#FFFFFF',
  darkCard: '#2D2D2D',
  
  text: '#1F2937',
  darkText: '#FFFFFF',
  textLight: '#6B7280',
  darkTextLight: '#A0AEC0',
  
  white: '#FFFFFF',
  black: '#000000',
  gray: '#9CA3AF',
  lightGray: '#E5E7EB',
  darkGray: '#4A5568',
  
  transparent: 'transparent',
};