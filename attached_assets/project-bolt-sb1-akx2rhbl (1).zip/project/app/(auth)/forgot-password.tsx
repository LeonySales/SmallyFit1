import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { COLORS } from '@/constants/colors';
import Button from '@/components/Button';

export default function ForgotPasswordScreen() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleResetPassword = () => {
    if (!email) {
      setError('Por favor, insira seu email');
      return;
    }

    setLoading(true);
    setError('');

    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
    }, 1500);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logo}>SmallyFit</Text>
        <Text style={styles.subtitle}>Recuperação de senha</Text>
      </View>

      <View style={styles.formContainer}>
        {success ? (
          <View style={styles.successContainer}>
            <Text style={styles.successTitle}>Email enviado!</Text>
            <Text style={styles.successText}>
              Enviamos instruções para redefinir sua senha para {email}. 
              Verifique sua caixa de entrada.
            </Text>
            <Button
              title="Voltar para o login"
              onPress={() => router.push('/(auth)/login')}
              fullWidth
              style={{ marginTop: 24 }}
            />
          </View>
        ) : (
          <>
            <Text style={styles.instructionText}>
              Digite seu email abaixo e enviaremos um link para redefinir sua senha.
            </Text>

            {error ? <Text style={styles.errorText}>{error}</Text> : null}

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={styles.input}
                placeholder="Seu email"
                value={email}
                onChangeText={setEmail}
                autoCapitalize="none"
                keyboardType="email-address"
              />
            </View>

            <Button
              title="Enviar link de recuperação"
              onPress={handleResetPassword}
              loading={loading}
              fullWidth
            />

            <TouchableOpacity
              onPress={() => router.push('/(auth)/login')}
              style={styles.backContainer}
            >
              <Text style={styles.backText}>Voltar para o login</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
    paddingHorizontal: 24,
  },
  header: {
    alignItems: 'center',
    marginTop: 80,
    marginBottom: 48,
  },
  logo: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 18,
    color: COLORS.text,
    marginBottom: 8,
  },
  formContainer: {
    width: '100%',
  },
  instructionText: {
    fontSize: 16,
    color: COLORS.textLight,
    marginBottom: 24,
    textAlign: 'center',
  },
  errorText: {
    fontSize: 14,
    color: COLORS.error,
    marginBottom: 16,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: 24,
  },
  label: {
    fontSize: 14,
    color: COLORS.text,
    marginBottom: 8,
  },
  input: {
    backgroundColor: COLORS.background,
    height: 48,
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    borderWidth: 1,
    borderColor: COLORS.lightGray,
  },
  backContainer: {
    alignItems: 'center',
    marginTop: 24,
  },
  backText: {
    fontSize: 14,
    color: COLORS.primary,
    fontWeight: '600',
  },
  successContainer: {
    alignItems: 'center',
    padding: 16,
  },
  successTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 16,
  },
  successText: {
    fontSize: 16,
    color: COLORS.text,
    textAlign: 'center',
    lineHeight: 24,
  },
});