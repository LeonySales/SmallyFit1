import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { COLORS } from '@/constants/colors';
import { Bell, CheckCheck, X } from 'lucide-react-native';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'achievement' | 'reminder' | 'motivation' | 'system';
  read: boolean;
  date: string;
}

export default function NotificationsScreen() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      title: 'Conquista Desbloqueada!',
      message: 'Parabéns! Você completou 7 dias consecutivos usando o app.',
      type: 'achievement',
      read: false,
      date: '2025-04-15T10:30:00',
    },
    {
      id: '2',
      title: 'Lembrete de Hidratação',
      message: 'Não se esqueça de beber água! Você está a 500ml da sua meta diária.',
      type: 'reminder',
      read: false,
      date: '2025-04-15T09:45:00',
    },
    {
      id: '3',
      title: 'Frase do Dia',
      message: 'A disciplina é a ponte entre metas e realizações. Continue firme!',
      type: 'motivation',
      read: true,
      date: '2025-04-14T08:00:00',
    },
    {
      id: '4',
      title: 'Desafio de Hoje',
      message: 'Seu desafio de exercícios está te esperando. Vamos começar?',
      type: 'reminder',
      read: true,
      date: '2025-04-14T07:30:00',
    },
    {
      id: '5',
      title: 'Novidades no App',
      message: 'Confira as novas funcionalidades disponíveis na versão Premium!',
      type: 'system',
      read: true,
      date: '2025-04-13T14:20:00',
    },
  ]);
  
  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id 
          ? { ...notification, read: true } 
          : notification
      )
    );
  };
  
  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
  };
  
  const deleteNotification = (id: string) => {
    setNotifications(prev => 
      prev.filter(notification => notification.id !== id)
    );
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };
  
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'achievement':
        return <View style={[styles.typeIndicator, { backgroundColor: COLORS.accent }]} />;
      case 'reminder':
        return <View style={[styles.typeIndicator, { backgroundColor: COLORS.secondary }]} />;
      case 'motivation':
        return <View style={[styles.typeIndicator, { backgroundColor: COLORS.primary }]} />;
      case 'system':
        return <View style={[styles.typeIndicator, { backgroundColor: COLORS.gray }]} />;
      default:
        return null;
    }
  };
  
  const unreadCount = notifications.filter(n => !n.read).length;
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Bell size={24} color={COLORS.primary} />
          <Text style={styles.headerTitle}>Notificações</Text>
        </View>
        
        {unreadCount > 0 && (
          <TouchableOpacity style={styles.markAllButton} onPress={markAllAsRead}>
            <CheckCheck size={16} color={COLORS.primary} />
            <Text style={styles.markAllText}>Marcar todas</Text>
          </TouchableOpacity>
        )}
      </View>
      
      {notifications.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Bell size={48} color={COLORS.gray} />
          <Text style={styles.emptyText}>Você não tem notificações</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.notificationsContainer}>
          {notifications.map(notification => (
            <TouchableOpacity
              key={notification.id}
              style={[
                styles.notificationItem,
                notification.read ? styles.readNotification : styles.unreadNotification,
              ]}
              onPress={() => markAsRead(notification.id)}
            >
              {getTypeIcon(notification.type)}
              
              <View style={styles.notificationContent}>
                <Text style={styles.notificationTitle}>{notification.title}</Text>
                <Text style={styles.notificationMessage}>{notification.message}</Text>
                <Text style={styles.notificationDate}>
                  {formatDate(notification.date)}
                </Text>
              </View>
              
              <TouchableOpacity
                style={styles.deleteButton}
                onPress={() => deleteNotification(notification.id)}
              >
                <X size={16} color={COLORS.gray} />
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
    marginLeft: 8,
  },
  markAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 16,
    backgroundColor: COLORS.backgroundLight,
  },
  markAllText: {
    fontSize: 12,
    color: COLORS.primary,
    fontWeight: '500',
    marginLeft: 4,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  emptyText: {
    fontSize: 16,
    color: COLORS.gray,
    marginTop: 16,
  },
  notificationsContainer: {
    padding: 16,
  },
  notificationItem: {
    flexDirection: 'row',
    backgroundColor: COLORS.white,
    borderRadius: 12,
    marginBottom: 12,
    padding: 16,
    shadowColor: COLORS.black,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  unreadNotification: {
    borderLeftWidth: 3,
    borderLeftColor: COLORS.primary,
  },
  readNotification: {
    opacity: 0.8,
  },
  typeIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 12,
    marginTop: 6,
  },
  notificationContent: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 4,
  },
  notificationMessage: {
    fontSize: 14,
    color: COLORS.textLight,
    marginBottom: 8,
    lineHeight: 20,
  },
  notificationDate: {
    fontSize: 12,
    color: COLORS.gray,
  },
  deleteButton: {
    padding: 4,
  },
});