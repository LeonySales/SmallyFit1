import React, { useState } from 'react';
import { View, Text, StyleSheet, Switch, ScrollView, TouchableOpacity } from 'react-native';
import { COLORS } from '@/constants/colors';
import Card from '@/components/Card';
import { Settings, Bell, Lock, CircleHelp as HelpCircle, Shield, LogOut } from 'lucide-react-native';
import { router } from 'expo-router';

export default function SettingsScreen() {
  const [notifications, setNotifications] = useState(true);
  const [reminders, setReminders] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [offline, setOffline] = useState(true);
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Settings size={24} color={COLORS.primary} />
        <Text style={styles.headerTitle}>Configurações</Text>
      </View>
      
      <Card title="Notificações">
        <View style={styles.settingItem}>
          <Text style={styles.settingLabel}>Todas as notificações</Text>
          <Switch
            value={notifications}
            onValueChange={setNotifications}
            trackColor={{ false: COLORS.lightGray, true: COLORS.primaryLight }}
            thumbColor={notifications ? COLORS.primary : COLORS.gray}
          />
        </View>
        
        <View style={styles.settingItem}>
          <Text style={styles.settingLabel}>Lembretes diários</Text>
          <Switch
            value={reminders}
            onValueChange={setReminders}
            trackColor={{ false: COLORS.lightGray, true: COLORS.primaryLight }}
            thumbColor={reminders ? COLORS.primary : COLORS.gray}
            disabled={!notifications}
          />
        </View>
        
        <TouchableOpacity style={styles.settingButton}>
          <Text style={styles.settingButtonText}>Configurar horários</Text>
        </TouchableOpacity>
      </Card>
      
      <Card title="Aparência">
        <View style={styles.settingItem}>
          <Text style={styles.settingLabel}>Modo escuro</Text>
          <Switch
            value={darkMode}
            onValueChange={setDarkMode}
            trackColor={{ false: COLORS.lightGray, true: COLORS.primaryLight }}
            thumbColor={darkMode ? COLORS.primary : COLORS.gray}
          />
        </View>
      </Card>
      
      <Card title="Armazenamento">
        <View style={styles.settingItem}>
          <Text style={styles.settingLabel}>Modo offline</Text>
          <Switch
            value={offline}
            onValueChange={setOffline}
            trackColor={{ false: COLORS.lightGray, true: COLORS.primaryLight }}
            thumbColor={offline ? COLORS.primary : COLORS.gray}
          />
        </View>
        <Text style={styles.settingDescription}>
          Habilite para usar o app sem conexão à internet. Os dados serão sincronizados automaticamente quando online.
        </Text>
      </Card>
      
      <Card title="Conta">
        <TouchableOpacity style={styles.menuItem}>
          <View style={styles.menuItemContent}>
            <Lock size={20} color={COLORS.text} />
            <Text style={styles.menuItemText}>Alterar senha</Text>
          </View>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <View style={styles.menuItemContent}>
            <Bell size={20} color={COLORS.text} />
            <Text style={styles.menuItemText}>Preferências de notificações</Text>
          </View>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <View style={styles.menuItemContent}>
            <Shield size={20} color={COLORS.text} />
            <Text style={styles.menuItemText}>Privacidade e dados</Text>
          </View>
        </TouchableOpacity>
      </Card>
      
      <Card title="Suporte">
        <TouchableOpacity style={styles.menuItem}>
          <View style={styles.menuItemContent}>
            <HelpCircle size={20} color={COLORS.text} />
            <Text style={styles.menuItemText}>Ajuda e suporte</Text>
          </View>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <View style={styles.menuItemContent}>
            <HelpCircle size={20} color={COLORS.text} />
            <Text style={styles.menuItemText}>Termos de uso</Text>
          </View>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <View style={styles.menuItemContent}>
            <HelpCircle size={20} color={COLORS.text} />
            <Text style={styles.menuItemText}>Política de privacidade</Text>
          </View>
        </TouchableOpacity>
      </Card>
      
      <TouchableOpacity 
        style={styles.logoutButton}
        onPress={() => router.replace('/(auth)/login')}
      >
        <LogOut size={20} color={COLORS.white} />
        <Text style={styles.logoutText}>Sair da conta</Text>
      </TouchableOpacity>
      
      <Text style={styles.versionText}>SmallyFit v1.0.0</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
    marginLeft: 8,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  settingLabel: {
    fontSize: 16,
    color: COLORS.text,
  },
  settingDescription: {
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 8,
    lineHeight: 20,
  },
  settingButton: {
    marginTop: 12,
    alignSelf: 'flex-start',
  },
  settingButtonText: {
    fontSize: 14,
    color: COLORS.primary,
    fontWeight: '500',
  },
  menuItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  menuItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuItemText: {
    fontSize: 16,
    color: COLORS.text,
    marginLeft: 12,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.error,
    paddingVertical: 12,
    borderRadius: 8,
    marginTop: 24,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.white,
    marginLeft: 8,
  },
  versionText: {
    textAlign: 'center',
    fontSize: 12,
    color: COLORS.textLight,
    marginTop: 16,
  },
});