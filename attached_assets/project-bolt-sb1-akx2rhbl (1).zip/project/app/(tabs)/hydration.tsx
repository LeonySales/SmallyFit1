import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { COLORS } from '@/constants/colors';
import WaterTracker from '@/components/WaterTracker';
import Card from '@/components/Card';
import { Droplets, TrendingUp } from 'lucide-react-native';

export default function HydrationScreen() {
  const [waterIntake, setWaterIntake] = useState(1300);
  const [waterGoal, setWaterGoal] = useState(2000);
  const [weeklyData, setWeeklyData] = useState([
    { day: 'Seg', value: 1800 },
    { day: 'Ter', value: 1600 },
    { day: 'Qua', value: 2000 },
    { day: 'Qui', value: 1500 },
    { day: 'Sex', value: 1300 },
    { day: 'Sáb', value: 0 },
    { day: 'Dom', value: 0 },
  ]);
  
  // Calculate max value for chart scale
  const maxValue = Math.max(...weeklyData.map(item => item.value), waterGoal);
  
  const addWater = (amount: number) => {
    const newTotal = waterIntake + amount;
    setWaterIntake(newTotal);
  };
  
  const subtractWater = (amount: number) => {
    const newTotal = Math.max(0, waterIntake - amount);
    setWaterIntake(newTotal);
  };
  
  // Update today's (Friday) value as user adds water
  useEffect(() => {
    const updatedData = [...weeklyData];
    updatedData[4].value = waterIntake;
    setWeeklyData(updatedData);
  }, [waterIntake]);
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Droplets size={24} color={COLORS.primary} />
        <Text style={styles.headerTitle}>Controle de Água</Text>
      </View>
      
      <WaterTracker
        currentML={waterIntake}
        goalML={waterGoal}
        onAdd={addWater}
        onSubtract={subtractWater}
      />
      
      <Card title="Histórico Semanal" style={styles.weeklyCard}>
        <View style={styles.chartHeader}>
          <Text style={styles.chartTitle}>Consumo de Água</Text>
          <View style={styles.chartLegend}>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: COLORS.secondary }]} />
              <Text style={styles.legendText}>Consumo</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendColor, { backgroundColor: COLORS.lightGray }]} />
              <Text style={styles.legendText}>Meta</Text>
            </View>
          </View>
        </View>
        
        <View style={styles.chartContainer}>
          {/* Draw the goal line */}
          <View 
            style={[
              styles.goalLine, 
              { bottom: `${(waterGoal / maxValue) * 100}%` }
            ]}
          />
          
          {/* Render the bars */}
          <View style={styles.barsContainer}>
            {weeklyData.map((item, index) => (
              <View key={index} style={styles.barColumn}>
                <View 
                  style={[
                    styles.bar, 
                    { height: `${(item.value / maxValue) * 100}%` }
                  ]}
                />
                <Text style={styles.barLabel}>{item.day}</Text>
              </View>
            ))}
          </View>
        </View>
      </Card>
      
      <Card title="Dicas de Hidratação" style={styles.tipsCard}>
        <View style={styles.tipItem}>
          <Droplets size={18} color={COLORS.secondary} />
          <Text style={styles.tipText}>
            Beba um copo de água logo ao acordar para hidratar seu corpo após a noite de sono.
          </Text>
        </View>
        
        <View style={styles.tipItem}>
          <Droplets size={18} color={COLORS.secondary} />
          <Text style={styles.tipText}>
            Configure lembretes a cada 1-2 horas para beber água regularmente.
          </Text>
        </View>
        
        <View style={styles.tipItem}>
          <Droplets size={18} color={COLORS.secondary} />
          <Text style={styles.tipText}>
            Adicione frutas como limão, laranja ou morango para dar sabor à água.
          </Text>
        </View>
      </Card>
      
      <Card title="Benefícios da Hidratação Adequada">
        <View style={styles.benefitItem}>
          <TrendingUp size={18} color={COLORS.primary} />
          <Text style={styles.benefitText}>
            Melhora o metabolismo e auxilia na perda de peso
          </Text>
        </View>
        
        <View style={styles.benefitItem}>
          <TrendingUp size={18} color={COLORS.primary} />
          <Text style={styles.benefitText}>
            Aumenta a disposição e reduz a fadiga
          </Text>
        </View>
        
        <View style={styles.benefitItem}>
          <TrendingUp size={18} color={COLORS.primary} />
          <Text style={styles.benefitText}>
            Melhora a aparência da pele e ajuda na desintoxicação
          </Text>
        </View>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
    marginLeft: 8,
  },
  weeklyCard: {
    marginTop: 16,
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
  },
  chartLegend: {
    flexDirection: 'row',
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 16,
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 2,
    marginRight: 4,
  },
  legendText: {
    fontSize: 12,
    color: COLORS.textLight,
  },
  chartContainer: {
    height: 200,
    width: '100%',
    position: 'relative',
  },
  goalLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: COLORS.lightGray,
    zIndex: 1,
  },
  barsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: '100%',
    paddingBottom: 24, // Space for labels
  },
  barColumn: {
    flex: 1,
    alignItems: 'center',
    height: '100%',
    justifyContent: 'flex-end',
  },
  bar: {
    width: 20,
    backgroundColor: COLORS.secondary,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
    minHeight: 4,
  },
  barLabel: {
    position: 'absolute',
    bottom: 0,
    fontSize: 12,
    color: COLORS.textLight,
  },
  tipsCard: {
    marginTop: 16,
  },
  tipItem: {
    flexDirection: 'row',
    marginBottom: 12,
    alignItems: 'flex-start',
  },
  tipText: {
    marginLeft: 8,
    fontSize: 14,
    color: COLORS.text,
    flex: 1,
    lineHeight: 20,
  },
  benefitItem: {
    flexDirection: 'row',
    marginBottom: 12,
    alignItems: 'flex-start',
  },
  benefitText: {
    marginLeft: 8,
    fontSize: 14,
    color: COLORS.text,
    flex: 1,
    lineHeight: 20,
  },
});