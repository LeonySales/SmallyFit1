import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Dumbbell, Chrome as Home, Building2 } from 'lucide-react-native';
import { COLORS } from '@/constants/colors';
import ChallengeCard from '@/components/ChallengeCard';
import ProgressBar from '@/components/ProgressBar';
import Card from '@/components/Card';
import Button from '@/components/Button';

export default function ChallengesScreen() {
  const [activeTab, setActiveTab] = useState<'home' | 'gym'>('home');
  const [weeklyProgress, setWeeklyProgress] = useState(0.57);

  const homeChallenges = [
    {
      id: '1',
      title: 'Iniciante: Força Total',
      description: '3 séries de 10 agachamentos, 10 flexões e 10 abdominais',
      completed: true,
      type: 'home',
      locked: false,
    },
    {
      id: '2',
      title: 'Queima de Gordura',
      description: '20 minutos de exercícios intervalados de alta intensidade',
      completed: false,
      type: 'home',
      locked: false,
    },
    {
      id: '3',
      title: 'Desafio Cardio',
      description: '30 minutos de exercícios cardiovasculares',
      completed: false,
      type: 'home',
      locked: true,
    },
  ];

  const gymChallenges = [
    {
      id: '4',
      title: 'Dia de Pernas',
      description: '4 séries de agachamentos, leg press e extensora',
      completed: false,
      type: 'gym',
      locked: false,
    },
    {
      id: '5',
      title: 'Superior Power',
      description: '4 séries de supino, puxada frontal e desenvolvimento',
      completed: false,
      type: 'gym',
      locked: false,
    },
    {
      id: '6',
      title: 'Cardiovascular',
      description: '20 minutos de esteira + 10 minutos de elíptico',
      completed: false,
      type: 'gym',
      locked: true,
    },
  ];

  const handleChallengePress = (id: string) => {
    // Handle challenge selection - would navigate to detail page in full app
    console.log('Challenge selected:', id);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Dumbbell size={24} color={COLORS.primary} />
        <Text style={styles.headerTitle}>Desafios Diários</Text>
      </View>

      <Card>
        <View style={styles.weeklyProgressContainer}>
          <Text style={styles.progressTitle}>Progresso semanal</Text>
          <ProgressBar 
            progress={weeklyProgress} 
            showPercentage 
            label="Desafios completados" 
          />
          <Text style={styles.progressSubtext}>
            Continue firme! Você já completou 4 de 7 desafios esta semana.
          </Text>
        </View>
      </Card>

      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'home' ? styles.activeTab : null,
          ]}
          onPress={() => setActiveTab('home')}
        >
          <Home 
            size={18} 
            color={activeTab === 'home' ? COLORS.primary : COLORS.textLight} 
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'home' ? styles.activeTabText : null,
            ]}
          >
            Em Casa
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'gym' ? styles.activeTab : null,
          ]}
          onPress={() => setActiveTab('gym')}
        >
          <Building2 
            size={18} 
            color={activeTab === 'gym' ? COLORS.primary : COLORS.textLight} 
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'gym' ? styles.activeTabText : null,
            ]}
          >
            Academia
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.challengesContainer}>
        {activeTab === 'home'
          ? homeChallenges.map((challenge) => (
              <ChallengeCard
                key={challenge.id}
                title={challenge.title}
                description={challenge.description}
                completed={challenge.completed}
                type={challenge.type as 'home' | 'gym'}
                locked={challenge.locked}
                onPress={() => handleChallengePress(challenge.id)}
              />
            ))
          : gymChallenges.map((challenge) => (
              <ChallengeCard
                key={challenge.id}
                title={challenge.title}
                description={challenge.description}
                completed={challenge.completed}
                type={challenge.type as 'home' | 'gym'}
                locked={challenge.locked}
                onPress={() => handleChallengePress(challenge.id)}
              />
            ))}
      </View>

      <View style={styles.proCardContainer}>
        <Card style={styles.proCard}>
          <Text style={styles.proCardTitle}>
            Desbloqueie Todos os Desafios
          </Text>
          <Text style={styles.proCardDescription}>
            Assine o plano Premium e tenha acesso a todos os desafios e recursos exclusivos do SmallyFit.
          </Text>
          <Button
            title="Assinar Premium"
            variant="secondary"
            fullWidth
            style={styles.proButton}
            onPress={() => console.log('Upgrade to premium')}
          />
        </Card>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
    marginLeft: 8,
  },
  weeklyProgressContainer: {
    width: '100%',
  },
  progressTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 12,
  },
  progressSubtext: {
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 8,
  },
  tabsContainer: {
    flexDirection: 'row',
    marginVertical: 16,
    backgroundColor: COLORS.white,
    borderRadius: 8,
    padding: 4,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 6,
  },
  activeTab: {
    backgroundColor: COLORS.background,
  },
  tabText: {
    fontSize: 14,
    color: COLORS.textLight,
    marginLeft: 6,
  },
  activeTabText: {
    color: COLORS.text,
    fontWeight: '500',
  },
  challengesContainer: {
    marginBottom: 16,
  },
  proCardContainer: {
    marginVertical: 16,
  },
  proCard: {
    backgroundColor: COLORS.primaryLight,
    borderColor: COLORS.primary,
    borderWidth: 1,
  },
  proCardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 8,
  },
  proCardDescription: {
    fontSize: 14,
    color: COLORS.text,
    marginBottom: 16,
    lineHeight: 20,
  },
  proButton: {
    backgroundColor: COLORS.primary,
  },
});