import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { COLORS } from '@/constants/colors';
import Card from '@/components/Card';
import { ChartLine as LineChart, TrendingDown, ChevronLeft, ChevronRight } from 'lucide-react-native';
import Button from '@/components/Button';

export default function ProgressScreen() {
  const [currentPeriod, setCurrentPeriod] = useState('Abril 2025');
  
  // Sample data
  const weightData = [80.5, 79.8, 79.2, 78.7, 78.1, 77.6, 77.2];
  const dates = ['01/04', '05/04', '09/04', '13/04', '17/04', '21/04', '25/04'];
  
  // Calculate weight loss
  const totalLoss = weightData[0] - weightData[weightData.length - 1];
  const percentageLoss = (totalLoss / weightData[0]) * 100;
  
  // Sample measurements
  const measurements = {
    waist: { current: 82, previous: 85 },
    hips: { current: 95, previous: 97 },
    arms: { current: 33, previous: 34 },
  };
  
  // Calculate BMI
  const height = 1.70; // in meters
  const currentWeight = weightData[weightData.length - 1];
  const bmi = currentWeight / (height * height);
  
  const getBmiCategory = (bmi: number) => {
    if (bmi < 18.5) return { category: 'Abaixo do peso', color: COLORS.warning };
    if (bmi < 25) return { category: 'Peso normal', color: COLORS.success };
    if (bmi < 30) return { category: 'Sobrepeso', color: COLORS.warning };
    return { category: 'Obesidade', color: COLORS.error };
  };
  
  const bmiInfo = getBmiCategory(bmi);
  
  // Render weight chart lines
  const renderChartLines = () => {
    const minWeight = Math.min(...weightData) - 1;
    const maxWeight = Math.max(...weightData) + 1;
    const range = maxWeight - minWeight;
    
    return weightData.map((weight, index) => {
      if (index === 0) return null;
      
      const prevWeight = weightData[index - 1];
      const prevX = (index - 1) / (weightData.length - 1) * 100;
      const currentX = index / (weightData.length - 1) * 100;
      
      const prevY = 100 - ((prevWeight - minWeight) / range) * 100;
      const currentY = 100 - ((weight - minWeight) / range) * 100;
      
      return (
        <View
          key={index}
          style={[
            styles.chartLine,
            {
              left: `${prevX}%`,
              width: `${currentX - prevX}%`,
              top: `${prevY}%`,
              height: `${currentY - prevY}%`,
              backgroundColor: prevWeight > weight ? COLORS.success : COLORS.error,
            },
          ]}
        />
      );
    });
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <LineChart size={24} color={COLORS.primary} />
        <Text style={styles.headerTitle}>Seu Progresso</Text>
      </View>
      
      <Card>
        <View style={styles.periodSelector}>
          <Button
            title=""
            onPress={() => {}}
            variant="text"
            style={styles.periodButton}
            textStyle={styles.periodButtonText}
          >
            <ChevronLeft size={20} color={COLORS.text} />
          </Button>
          <Text style={styles.periodText}>{currentPeriod}</Text>
          <Button
            title=""
            onPress={() => {}}
            variant="text"
            style={styles.periodButton}
            textStyle={styles.periodButtonText}
          >
            <ChevronRight size={20} color={COLORS.text} />
          </Button>
        </View>
        
        <View style={styles.weightSummary}>
          <View>
            <Text style={styles.weightSummaryLabel}>Peso inicial</Text>
            <Text style={styles.weightValue}>{weightData[0]} kg</Text>
          </View>
          <View style={styles.weightChange}>
            <TrendingDown size={24} color={COLORS.success} />
            <Text style={styles.weightLossText}>
              -{totalLoss.toFixed(1)} kg ({percentageLoss.toFixed(1)}%)
            </Text>
          </View>
          <View>
            <Text style={styles.weightSummaryLabel}>Peso atual</Text>
            <Text style={styles.weightValue}>{weightData[weightData.length - 1]} kg</Text>
          </View>
        </View>
        
        <View style={styles.chartContainer}>
          <View style={styles.chartArea}>
            {renderChartLines()}
            
            {weightData.map((weight, index) => (
              <View
                key={`dot-${index}`}
                style={[
                  styles.chartDot,
                  {
                    left: `${index / (weightData.length - 1) * 100}%`,
                    top: `${
                      100 -
                      ((weight - Math.min(...weightData) + 1) /
                        (Math.max(...weightData) - Math.min(...weightData) + 2)) *
                        100
                    }%`,
                  },
                ]}
              />
            ))}
          </View>
          <View style={styles.chartLabels}>
            {dates.map((date, index) => (
              <Text key={`label-${index}`} style={styles.chartLabel}>
                {date}
              </Text>
            ))}
          </View>
        </View>
      </Card>
      
      <Card title="Índice de Massa Corporal (IMC)" style={styles.bmiCard}>
        <View style={styles.bmiContainer}>
          <View style={styles.bmiValueContainer}>
            <Text style={styles.bmiValue}>{bmi.toFixed(1)}</Text>
          </View>
          <View style={styles.bmiInfo}>
            <Text style={[styles.bmiCategory, { color: bmiInfo.color }]}>
              {bmiInfo.category}
            </Text>
            <Text style={styles.bmiDescription}>
              O IMC é uma medida que usa sua altura e peso para determinar 
              se seu peso é saudável.
            </Text>
          </View>
        </View>
      </Card>
      
      <Card title="Medidas Corporais">
        <View style={styles.measurementsContainer}>
          <View style={styles.measurementItem}>
            <Text style={styles.measurementLabel}>Cintura</Text>
            <View style={styles.measurementValues}>
              <Text style={styles.measurementCurrent}>{measurements.waist.current} cm</Text>
              <Text style={styles.measurementChange}>
                {(measurements.waist.previous - measurements.waist.current > 0 ? '-' : '+')}
                {Math.abs(measurements.waist.previous - measurements.waist.current)} cm
              </Text>
            </View>
          </View>
          
          <View style={styles.measurementItem}>
            <Text style={styles.measurementLabel}>Quadril</Text>
            <View style={styles.measurementValues}>
              <Text style={styles.measurementCurrent}>{measurements.hips.current} cm</Text>
              <Text style={styles.measurementChange}>
                {(measurements.hips.previous - measurements.hips.current > 0 ? '-' : '+')}
                {Math.abs(measurements.hips.previous - measurements.hips.current)} cm
              </Text>
            </View>
          </View>
          
          <View style={styles.measurementItem}>
            <Text style={styles.measurementLabel}>Braços</Text>
            <View style={styles.measurementValues}>
              <Text style={styles.measurementCurrent}>{measurements.arms.current} cm</Text>
              <Text style={styles.measurementChange}>
                {(measurements.arms.previous - measurements.arms.current > 0 ? '-' : '+')}
                {Math.abs(measurements.arms.previous - measurements.arms.current)} cm
              </Text>
            </View>
          </View>
        </View>
        
        <Button
          title="Atualizar Medidas"
          variant="outline"
          onPress={() => {}}
          fullWidth
          style={styles.updateButton}
        />
      </Card>
      
      <Card style={styles.motivationCard}>
        <Text style={styles.motivationText}>
          "Seu corpo consegue quase tudo. É sua mente que você precisa convencer."
        </Text>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
    marginLeft: 8,
  },
  periodSelector: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  periodButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 0,
  },
  periodButtonText: {
    margin: 0,
  },
  periodText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginHorizontal: 12,
  },
  weightSummary: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  weightSummaryLabel: {
    fontSize: 12,
    color: COLORS.textLight,
    marginBottom: 4,
  },
  weightValue: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
  },
  weightChange: {
    alignItems: 'center',
  },
  weightLossText: {
    fontSize: 16,
    fontWeight: '500',
    color: COLORS.success,
    marginTop: 4,
  },
  chartContainer: {
    height: 200,
    marginTop: 16,
  },
  chartArea: {
    height: 160,
    width: '100%',
    position: 'relative',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  chartLine: {
    position: 'absolute',
    height: 2,
    backgroundColor: COLORS.primary,
    zIndex: 1,
  },
  chartDot: {
    position: 'absolute',
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: COLORS.primary,
    zIndex: 2,
    marginLeft: -4,
    marginTop: -4,
  },
  chartLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 8,
  },
  chartLabel: {
    fontSize: 10,
    color: COLORS.textLight,
    textAlign: 'center',
    width: 40,
    marginLeft: -20,
  },
  bmiCard: {
    marginTop: 16,
  },
  bmiContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  bmiValueContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: COLORS.primaryLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  bmiValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  bmiInfo: {
    flex: 1,
  },
  bmiCategory: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  bmiDescription: {
    fontSize: 12,
    color: COLORS.textLight,
    lineHeight: 16,
  },
  measurementsContainer: {
    marginBottom: 16,
  },
  measurementItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
    paddingVertical: 12,
  },
  measurementLabel: {
    fontSize: 16,
    color: COLORS.text,
  },
  measurementValues: {
    alignItems: 'flex-end',
  },
  measurementCurrent: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
  },
  measurementChange: {
    fontSize: 12,
    color: COLORS.success,
    marginTop: 2,
  },
  updateButton: {
    marginTop: 8,
  },
  motivationCard: {
    backgroundColor: COLORS.primaryLight,
    marginTop: 16,
  },
  motivationText: {
    fontSize: 16,
    fontStyle: 'italic',
    color: COLORS.primary,
    textAlign: 'center',
    lineHeight: 24,
  },
});