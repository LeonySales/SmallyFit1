import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity } from 'react-native';
import { COLORS } from '@/constants/colors';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { User, Settings, LogOut, Camera, CreditCard as Edit3, ChevronRight } from 'lucide-react-native';
import { router } from 'expo-router';

export default function ProfileScreen() {
  const [user, setUser] = useState({
    name: 'Maria Silva',
    email: 'maria@example.com',
    plan: 'free', // 'free' or 'premium'
    joinDate: '10 de Abril, 2025',
    goal: 'Emagrecimento Geral',
    initialWeight: 80.5,
    currentWeight: 77.2,
    targetWeight: 70,
    height: 170,
  });
  
  const progressPercentage = (
    (user.initialWeight - user.currentWeight) / 
    (user.initialWeight - user.targetWeight)
  ) * 100;
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <User size={40} color={COLORS.white} />
          </View>
          <TouchableOpacity style={styles.cameraButton}>
            <Camera size={16} color={COLORS.white} />
          </TouchableOpacity>
        </View>
        
        <View style={styles.userInfo}>
          <Text style={styles.userName}>{user.name}</Text>
          <Text style={styles.userEmail}>{user.email}</Text>
          <View style={styles.planBadge}>
            <Text style={styles.planText}>
              {user.plan === 'premium' ? 'Plano Premium' : 'Plano Gratuito'}
            </Text>
          </View>
        </View>
      </View>
      
      <Card>
        <View style={styles.goalContainer}>
          <View style={styles.goalHeader}>
            <Text style={styles.goalTitle}>Objetivo</Text>
            <TouchableOpacity style={styles.editButton}>
              <Edit3 size={16} color={COLORS.primary} />
            </TouchableOpacity>
          </View>
          
          <Text style={styles.goalText}>{user.goal}</Text>
          
          <View style={styles.weightGoalContainer}>
            <Text style={styles.weightGoalText}>
              De {user.initialWeight}kg para {user.targetWeight}kg
            </Text>
            <View style={styles.progressBarContainer}>
              <View 
                style={[
                  styles.progressBar, 
                  { width: `${Math.min(100, Math.max(0, progressPercentage))}%` }
                ]}
              />
            </View>
            <Text style={styles.progressText}>
              {progressPercentage.toFixed(0)}% concluído
            </Text>
          </View>
        </View>
      </Card>
      
      <Card title="Minha Conta">
        <TouchableOpacity style={styles.menuItem}>
          <View style={styles.menuItemLeft}>
            <User size={20} color={COLORS.primary} />
            <Text style={styles.menuItemText}>Dados Pessoais</Text>
          </View>
          <ChevronRight size={16} color={COLORS.gray} />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <View style={styles.menuItemLeft}>
            <Settings size={20} color={COLORS.primary} />
            <Text style={styles.menuItemText}>Configurações</Text>
          </View>
          <ChevronRight size={16} color={COLORS.gray} />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <View style={styles.menuItemLeft}>
            <LogOut size={20} color={COLORS.error} />
            <Text style={[styles.menuItemText, { color: COLORS.error }]}>
              Sair da Conta
            </Text>
          </View>
        </TouchableOpacity>
      </Card>
      
      {user.plan === 'free' && (
        <Card style={styles.upgradeCard}>
          <Text style={styles.upgradeTitle}>Atualize para o Premium!</Text>
          <Text style={styles.upgradeDescription}>
            Desbloqueie todos os recursos do SmallyFit e alcance seus objetivos mais rápido.
          </Text>
          
          <View style={styles.pricingContainer}>
            <View style={styles.pricingLeft}>
              <Text style={styles.priceCurrent}>R$29,90</Text>
              <Text style={styles.priceRegular}>depois R$49,90/mês</Text>
            </View>
            <Text style={styles.pricingRight}>Primeiros 7 dias grátis</Text>
          </View>
          
          <Button
            title="Assinar Premium"
            variant="secondary"
            onPress={() => {}}
            fullWidth
            style={styles.upgradeButton}
          />
        </Card>
      )}
      
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Membro desde {user.joinDate}
        </Text>
        <Text style={styles.footerVersion}>
          SmallyFit v1.0.0
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cameraButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: COLORS.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: COLORS.white,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    color: COLORS.textLight,
    marginBottom: 8,
  },
  planBadge: {
    backgroundColor: COLORS.primaryLight,
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  planText: {
    fontSize: 12,
    fontWeight: '500',
    color: COLORS.primary,
  },
  goalContainer: {
    width: '100%',
  },
  goalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  goalTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
  },
  editButton: {
    padding: 4,
  },
  goalText: {
    fontSize: 18,
    fontWeight: '500',
    color: COLORS.primary,
    marginBottom: 16,
  },
  weightGoalContainer: {
    width: '100%',
  },
  weightGoalText: {
    fontSize: 14,
    color: COLORS.text,
    marginBottom: 8,
  },
  progressBarContainer: {
    height: 8,
    backgroundColor: COLORS.lightGray,
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressBar: {
    height: '100%',
    backgroundColor: COLORS.success,
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
    color: COLORS.textLight,
    alignSelf: 'flex-end',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuItemText: {
    fontSize: 16,
    color: COLORS.text,
    marginLeft: 12,
  },
  upgradeCard: {
    marginTop: 16,
    backgroundColor: COLORS.primaryLight,
  },
  upgradeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 8,
  },
  upgradeDescription: {
    fontSize: 14,
    color: COLORS.text,
    marginBottom: 16,
    lineHeight: 20,
  },
  pricingContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  pricingLeft: {},
  priceCurrent: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  priceRegular: {
    fontSize: 12,
    color: COLORS.textLight,
  },
  pricingRight: {
    fontSize: 14,
    fontWeight: '500',
    color: COLORS.accent,
  },
  upgradeButton: {
    backgroundColor: COLORS.primary,
  },
  footer: {
    marginTop: 24,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    color: COLORS.textLight,
    marginBottom: 8,
  },
  footerVersion: {
    fontSize: 12,
    color: COLORS.gray,
  },
});