import { Tabs } from 'expo-router';
import { Chrome as Home, Dumbbell, Apple, ChartLine as LineChart, Droplets, Trophy, Bell, User, Settings } from 'lucide-react-native';
import { StyleSheet } from 'react-native';
import { COLORS } from '@/constants/colors';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.gray,
        tabBarLabelStyle: styles.tabBarLabel,
        tabBarStyle: styles.tabBar,
        headerStyle: styles.header,
        headerTitleStyle: styles.headerTitle,
        headerTintColor: COLORS.white,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Início',
          tabBarIcon: ({ color, size }) => <Home size={size} color={color} />,
          headerTitle: 'SmallyFit'
        }}
      />
      <Tabs.Screen
        name="challenges"
        options={{
          title: 'Desafios',
          tabBarIcon: ({ color, size }) => <Dumbbell size={size} color={color} />,
          headerTitle: 'Desafios Diários'
        }}
      />
      <Tabs.Screen
        name="nutrition"
        options={{
          title: 'Alimentação',
          tabBarIcon: ({ color, size }) => <Apple size={size} color={color} />,
          headerTitle: 'Alimentação Saudável'
        }}
      />
      <Tabs.Screen
        name="progress"
        options={{
          title: 'Progresso',
          tabBarIcon: ({ color, size }) => <LineChart size={size} color={color} />,
          headerTitle: 'Seu Progresso'
        }}
      />
      <Tabs.Screen
        name="hydration"
        options={{
          title: 'Hidratação',
          tabBarIcon: ({ color, size }) => <Droplets size={size} color={color} />,
          headerTitle: 'Controle de Água'
        }}
      />
      <Tabs.Screen
        name="achievements"
        options={{
          title: 'Conquistas',
          tabBarIcon: ({ color, size }) => <Trophy size={size} color={color} />,
          headerTitle: 'Suas Conquistas'
        }}
      />
      <Tabs.Screen
        name="notifications"
        options={{
          title: 'Avisos',
          tabBarIcon: ({ color, size }) => <Bell size={size} color={color} />,
          headerTitle: 'Notificações'
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Perfil',
          tabBarIcon: ({ color, size }) => <User size={size} color={color} />,
          headerTitle: 'Seu Perfil'
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Config',
          tabBarIcon: ({ color, size }) => <Settings size={size} color={color} />,
          headerTitle: 'Configurações'
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: COLORS.white,
    borderTopWidth: 1,
    borderTopColor: COLORS.lightGray,
    height: 60,
  },
  tabBarLabel: {
    fontSize: 10,
    fontWeight: '500',
    marginBottom: 4,
  },
  header: {
    backgroundColor: COLORS.primary,
  },
  headerTitle: {
    fontWeight: 'bold',
    fontSize: 18,
  },
});