import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { COLORS } from '@/constants/colors';
import Achievement from '@/components/Achievement';
import Card from '@/components/Card';
import { Trophy } from 'lucide-react-native';

export default function AchievementsScreen() {
  // Sample achievements data
  const achievements = [
    {
      id: '1',
      title: 'Primeira Semana',
      description: 'Complete 7 dias consecutivos de utilização do app',
      level: 'bronze',
      unlocked: true,
    },
    {
      id: '2',
      title: 'Mestre da Hidratação',
      description: 'Atinja sua meta de água por 5 dias consecutivos',
      level: 'silver',
      unlocked: true,
    },
    {
      id: '3',
      title: 'Desafio Aceito',
      description: 'Complete 10 desafios de exercícios',
      level: 'gold',
      unlocked: false,
      progress: 0.6,
    },
    {
      id: '4',
      title: 'Nutrição Balanceada',
      description: 'Registre todas as suas refeições por 14 dias',
      level: 'platinum',
      unlocked: false,
      progress: 0.25,
    },
    {
      id: '5',
      title: 'Um Mês de Dedicação',
      description: 'Complete 30 dias de uso do aplicativo',
      level: 'gold',
      unlocked: false,
      progress: 0.15,
    },
  ];
  
  // Calculate user level based on unlocked achievements
  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalCount = achievements.length;
  
  const getUserLevel = () => {
    if (unlockedCount >= 4) return 'Monstro';
    if (unlockedCount >= 3) return 'Guerreiro';
    if (unlockedCount >= 2) return 'Focado';
    return 'Iniciante';
  };
  
  const getProgressToNextLevel = () => {
    if (unlockedCount >= 4) return 1; // Max level
    if (unlockedCount >= 3) return unlockedCount / 4;
    if (unlockedCount >= 2) return unlockedCount / 3;
    if (unlockedCount >= 1) return unlockedCount / 2;
    return 0;
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Trophy size={24} color={COLORS.primary} />
        <Text style={styles.headerTitle}>Suas Conquistas</Text>
      </View>
      
      <Card style={styles.levelCard}>
        <View style={styles.levelHeader}>
          <View>
            <Text style={styles.levelLabel}>Seu nível</Text>
            <Text style={styles.levelName}>{getUserLevel()}</Text>
          </View>
          <View style={styles.trophyContainer}>
            <Trophy size={32} color={COLORS.accent} />
            <Text style={styles.trophyCount}>{unlockedCount}/{totalCount}</Text>
          </View>
        </View>
        
        <View style={styles.progressBarContainer}>
          <View 
            style={[
              styles.progressBar, 
              { width: `${getProgressToNextLevel() * 100}%` }
            ]}
          />
        </View>
        
        <Text style={styles.nextLevelText}>
          {unlockedCount >= 4
            ? 'Parabéns! Você atingiu o nível máximo!'
            : `Desbloqueie mais ${unlockedCount >= 3 ? '1' : unlockedCount >= 2 ? '1' : '1'} conquistas para o próximo nível`}
        </Text>
      </Card>
      
      <Text style={styles.sectionTitle}>Todas as Conquistas</Text>
      
      {achievements.map((achievement) => (
        <Achievement
          key={achievement.id}
          title={achievement.title}
          description={achievement.description}
          level={achievement.level as 'bronze' | 'silver' | 'gold' | 'platinum'}
          unlocked={achievement.unlocked}
          progress={achievement.progress}
        />
      ))}
      
      <Card style={styles.exploreMoreCard}>
        <Text style={styles.exploreMoreTitle}>
          Mais Conquistas Disponíveis no Plano Premium!
        </Text>
        <Text style={styles.exploreMoreText}>
          Assine o plano premium para desbloquear mais conquistas e aprimorar sua jornada de saúde.
        </Text>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
    marginLeft: 8,
  },
  levelCard: {
    backgroundColor: COLORS.white,
    marginBottom: 24,
  },
  levelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  levelLabel: {
    fontSize: 14,
    color: COLORS.textLight,
  },
  levelName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginTop: 4,
  },
  trophyContainer: {
    alignItems: 'center',
  },
  trophyCount: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.text,
    marginTop: 4,
  },
  progressBarContainer: {
    width: '100%',
    height: 8,
    backgroundColor: COLORS.lightGray,
    borderRadius: 4,
    marginTop: 16,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: COLORS.primary,
    borderRadius: 4,
  },
  nextLevelText: {
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 16,
  },
  exploreMoreCard: {
    backgroundColor: COLORS.primaryLight,
    marginTop: 24,
  },
  exploreMoreTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.primary,
    marginBottom: 8,
  },
  exploreMoreText: {
    fontSize: 14,
    color: COLORS.text,
    lineHeight: 20,
  },
});