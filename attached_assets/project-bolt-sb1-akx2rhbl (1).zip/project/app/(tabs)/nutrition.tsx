import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { COLORS } from '@/constants/colors';
import MealCard from '@/components/MealCard';
import Card from '@/components/Card';
import { Apple, ChevronDown } from 'lucide-react-native';

export default function NutritionScreen() {
  const [selectedGoal, setSelectedGoal] = useState('weight-loss');
  const [showGoalSelector, setShowGoalSelector] = useState(false);
  
  const goals = [
    { id: 'weight-loss', name: 'Emagrecimento Geral' },
    { id: 'belly-fat', name: 'Redução de Gordura Abdominal' },
    { id: 'muscle', name: 'Definição Muscular' },
  ];
  
  const breakfastMeals = [
    {
      id: '1',
      title: 'Omelete de Claras',
      description: 'Omelete de 3 claras com espinafre, tomate e uma fatia de pão integral.',
      calories: 280,
      mealType: 'breakfast',
    },
    {
      id: '2',
      title: 'Tigela de Aveia',
      description: 'Aveia com leite desnatado, banana, canela e uma colher de mel.',
      calories: 320,
      mealType: 'breakfast',
    },
  ];
  
  const lunchMeals = [
    {
      id: '3',
      title: 'Frango Grelhado com Salada',
      description: 'Peito de frango grelhado, salada verde, tomate, pepino e azeite.',
      calories: 420,
      mealType: 'lunch',
    },
    {
      id: '4',
      title: 'Peixe com Legumes',
      description: 'Filé de peixe assado com mix de legumes e arroz integral.',
      calories: 380,
      mealType: 'lunch',
    },
  ];
  
  const snackMeals = [
    {
      id: '5',
      title: 'Iogurte com Frutas',
      description: 'Iogurte natural com morangos, blueberries e uma colher de granola.',
      calories: 180,
      mealType: 'snack',
    },
    {
      id: '6',
      title: 'Mix de Oleaginosas',
      description: 'Mistura de amêndoas, castanhas e nozes (30g).',
      calories: 170,
      mealType: 'snack',
    },
  ];
  
  const dinnerMeals = [
    {
      id: '7',
      title: 'Salada de Atum',
      description: 'Atum em água, folhas verdes, tomate, cebola e azeite.',
      calories: 310,
      mealType: 'dinner',
    },
    {
      id: '8',
      title: 'Omelete de Legumes',
      description: 'Omelete com 2 ovos, abobrinha, cenoura e queijo branco.',
      calories: 350,
      mealType: 'dinner',
    },
  ];
  
  const handleMealPress = (id: string) => {
    // Navigate to meal details in full implementation
    console.log('Meal selected:', id);
  };
  
  const renderMealsList = (meals: any[], title: string) => (
    <>
      <Text style={styles.mealTypeTitle}>{title}</Text>
      {meals.map((meal) => (
        <MealCard
          key={meal.id}
          title={meal.title}
          description={meal.description}
          calories={meal.calories}
          mealType={meal.mealType as any}
          onPress={() => handleMealPress(meal.id)}
        />
      ))}
    </>
  );
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Apple size={24} color={COLORS.primary} />
        <Text style={styles.headerTitle}>Alimentação Saudável</Text>
      </View>
      
      <Card style={styles.nutritionSummary}>
        <Text style={styles.summaryTitle}>Resumo Nutricional</Text>
        <View style={styles.macrosContainer}>
          <View style={styles.macroItem}>
            <Text style={styles.macroValue}>1,850</Text>
            <Text style={styles.macroLabel}>Calorias</Text>
          </View>
          <View style={styles.macroItem}>
            <Text style={styles.macroValue}>125g</Text>
            <Text style={styles.macroLabel}>Proteínas</Text>
          </View>
          <View style={styles.macroItem}>
            <Text style={styles.macroValue}>180g</Text>
            <Text style={styles.macroLabel}>Carboidratos</Text>
          </View>
          <View style={styles.macroItem}>
            <Text style={styles.macroValue}>55g</Text>
            <Text style={styles.macroLabel}>Gorduras</Text>
          </View>
        </View>
      </Card>
      
      <TouchableOpacity 
        style={styles.goalSelector} 
        onPress={() => setShowGoalSelector(!showGoalSelector)}
      >
        <Text style={styles.goalSelectorLabel}>Objetivo:</Text>
        <Text style={styles.selectedGoal}>
          {goals.find(g => g.id === selectedGoal)?.name}
        </Text>
        <ChevronDown size={20} color={COLORS.text} />
      </TouchableOpacity>
      
      {showGoalSelector && (
        <View style={styles.goalOptions}>
          {goals.map((goal) => (
            <TouchableOpacity
              key={goal.id}
              style={[
                styles.goalOption,
                selectedGoal === goal.id && styles.selectedGoalOption,
              ]}
              onPress={() => {
                setSelectedGoal(goal.id);
                setShowGoalSelector(false);
              }}
            >
              <Text
                style={[
                  styles.goalOptionText,
                  selectedGoal === goal.id && styles.selectedGoalOptionText,
                ]}
              >
                {goal.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
      
      <View style={styles.mealsContainer}>
        {renderMealsList(breakfastMeals, 'Café da Manhã')}
        {renderMealsList(lunchMeals, 'Almoço')}
        {renderMealsList(snackMeals, 'Lanches')}
        {renderMealsList(dinnerMeals, 'Jantar')}
      </View>
      
      <Card style={styles.tipCard}>
        <Text style={styles.tipTitle}>Dica do Nutricionista</Text>
        <Text style={styles.tipText}>
          Lembre-se de beber bastante água entre as refeições, mas evite beber grandes quantidades durante as refeições para não prejudicar a digestão.
        </Text>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
    marginLeft: 8,
  },
  nutritionSummary: {
    marginBottom: 16,
  },
  summaryTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 12,
  },
  macrosContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  macroItem: {
    alignItems: 'center',
  },
  macroValue: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.primary,
  },
  macroLabel: {
    fontSize: 12,
    color: COLORS.textLight,
    marginTop: 4,
  },
  goalSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    padding: 12,
    borderRadius: 8,
    marginVertical: 16,
  },
  goalSelectorLabel: {
    fontSize: 14,
    color: COLORS.textLight,
    marginRight: 8,
  },
  selectedGoal: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
    flex: 1,
  },
  goalOptions: {
    backgroundColor: COLORS.white,
    borderRadius: 8,
    marginTop: -12,
    marginBottom: 16,
    padding: 8,
    shadowColor: COLORS.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  goalOption: {
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 4,
  },
  selectedGoalOption: {
    backgroundColor: COLORS.primaryLight,
  },
  goalOptionText: {
    fontSize: 14,
    color: COLORS.text,
  },
  selectedGoalOptionText: {
    fontWeight: '600',
    color: COLORS.primary,
  },
  mealsContainer: {
    marginBottom: 16,
  },
  mealTypeTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginTop: 16,
    marginBottom: 8,
  },
  tipCard: {
    backgroundColor: COLORS.secondaryLight,
    marginTop: 16,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 8,
  },
  tipText: {
    fontSize: 14,
    color: COLORS.text,
    lineHeight: 20,
  },
});