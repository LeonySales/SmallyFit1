import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { COLORS } from '@/constants/colors';
import Card from '@/components/Card';
import ProgressBar from '@/components/ProgressBar';
import { Dumbbell, Apple, Droplets, Trophy } from 'lucide-react-native';
import { router } from 'expo-router';

export default function HomeScreen() {
  const [waterProgress, setWaterProgress] = useState(0.65);
  const [username, setUsername] = useState('Maria');
  const [streakDays, setStreakDays] = useState(5);
  
  const renderQuickAction = (
    icon: React.ReactNode,
    title: string,
    onPress: () => void
  ) => (
    <TouchableOpacity style={styles.quickAction} onPress={onPress}>
      {icon}
      <Text style={styles.quickActionText}>{title}</Text>
    </TouchableOpacity>
  );
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.welcomeSection}>
        <Text style={styles.welcomeText}>Olá, {username}!</Text>
        <Text style={styles.dateText}>
          {new Date().toLocaleDateString('pt-BR', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
          })}
        </Text>
      </View>
      
      <Card style={styles.streakCard}>
        <View style={styles.streakContent}>
          <View>
            <Text style={styles.streakTitle}>Seu desempenho</Text>
            <Text style={styles.streakSubtitle}>
              Você está mantendo seu foco há:
            </Text>
          </View>
          <View style={styles.streakCountContainer}>
            <Text style={styles.streakCount}>{streakDays}</Text>
            <Text style={styles.streakLabel}>dias</Text>
          </View>
        </View>
        <Text style={styles.streakMotivation}>
          Continue assim! Você está no caminho certo.
        </Text>
      </Card>
      
      <Text style={styles.sectionTitle}>Ações rápidas</Text>
      <View style={styles.quickActionsContainer}>
        {renderQuickAction(
          <Dumbbell size={24} color={COLORS.primary} />,
          'Treino',
          () => router.push('/(tabs)/challenges')
        )}
        {renderQuickAction(
          <Apple size={24} color={COLORS.primary} />,
          'Refeições',
          () => router.push('/(tabs)/nutrition')
        )}
        {renderQuickAction(
          <Droplets size={24} color={COLORS.primary} />,
          'Água',
          () => router.push('/(tabs)/hydration')
        )}
        {renderQuickAction(
          <Trophy size={24} color={COLORS.primary} />,
          'Conquistas',
          () => router.push('/(tabs)/achievements')
        )}
      </View>
      
      <Card title="Progresso diário">
        <View style={styles.progressItem}>
          <Text style={styles.progressLabel}>Treino diário</Text>
          <ProgressBar progress={0.5} height={8} />
          <Text style={styles.progressText}>1 de 2 treinos</Text>
        </View>
        
        <View style={styles.progressItem}>
          <Text style={styles.progressLabel}>Consumo de água</Text>
          <ProgressBar 
            progress={waterProgress} 
            height={8} 
            progressColor={COLORS.secondary}
          />
          <Text style={styles.progressText}>1,3L de 2L</Text>
        </View>
        
        <View style={styles.progressItem}>
          <Text style={styles.progressLabel}>Refeições registradas</Text>
          <ProgressBar 
            progress={0.75} 
            height={8} 
            progressColor={COLORS.accent}
          />
          <Text style={styles.progressText}>3 de 4 refeições</Text>
        </View>
      </Card>
      
      <Card title="Dica do dia">
        <Text style={styles.tipText}>
          Adicionar limão à água pode aumentar sua hidratação e trazer benefícios à digestão.
        </Text>
      </Card>
      
      <View style={styles.motivationContainer}>
        <Text style={styles.motivationText}>
          "O sucesso não acontece da noite para o dia. Mantenha a consistência!"
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 16,
    paddingBottom: 32,
  },
  welcomeSection: {
    marginBottom: 24,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  dateText: {
    fontSize: 14,
    color: COLORS.textLight,
    marginTop: 4,
  },
  streakCard: {
    backgroundColor: COLORS.primary,
    marginBottom: 24,
  },
  streakContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  streakTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.white,
  },
  streakSubtitle: {
    fontSize: 14,
    color: COLORS.white,
    opacity: 0.9,
    marginTop: 4,
  },
  streakCountContainer: {
    alignItems: 'center',
  },
  streakCount: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.white,
  },
  streakLabel: {
    fontSize: 14,
    color: COLORS.white,
    opacity: 0.9,
  },
  streakMotivation: {
    fontSize: 14,
    color: COLORS.white,
    marginTop: 16,
    opacity: 0.9,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 16,
  },
  quickActionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  quickAction: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    width: '22%',
    shadowColor: COLORS.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  quickActionText: {
    fontSize: 12,
    color: COLORS.text,
    marginTop: 8,
    textAlign: 'center',
  },
  progressItem: {
    marginBottom: 16,
  },
  progressLabel: {
    fontSize: 14,
    color: COLORS.text,
    marginBottom: 8,
  },
  progressText: {
    fontSize: 12,
    color: COLORS.textLight,
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  tipText: {
    fontSize: 14,
    color: COLORS.text,
    lineHeight: 20,
  },
  motivationContainer: {
    marginTop: 16,
    padding: 16,
    backgroundColor: COLORS.white,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.accent,
  },
  motivationText: {
    fontSize: 16,
    fontStyle: 'italic',
    color: COLORS.text,
    textAlign: 'center',
  },
});