import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { COLORS } from '@/constants/colors';
import { Apple } from 'lucide-react-native';

interface MealCardProps {
  title: string;
  description: string;
  calories: number;
  mealType: 'breakfast' | 'lunch' | 'snack' | 'dinner';
  onPress: () => void;
}

export default function MealCard({
  title,
  description,
  calories,
  mealType,
  onPress,
}: MealCardProps) {
  const getMealTypeLabel = () => {
    switch (mealType) {
      case 'breakfast':
        return 'Café da Manhã';
      case 'lunch':
        return 'Almoço';
      case 'snack':
        return 'Lanche';
      case 'dinner':
        return 'Jantar';
    }
  };
  
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.header}>
        <Apple size={18} color={COLORS.primary} />
        <Text style={styles.mealType}>{getMealTypeLabel()}</Text>
        <View style={styles.caloriesContainer}>
          <Text style={styles.calories}>{calories} kcal</Text>
        </View>
      </View>
      
      <View style={styles.content}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.description} numberOfLines={2}>
          {description}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    marginVertical: 8,
    shadowColor: COLORS.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  mealType: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
    marginLeft: 8,
  },
  caloriesContainer: {
    marginLeft: 'auto',
    backgroundColor: COLORS.primaryLight,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
  },
  calories: {
    fontSize: 12,
    fontWeight: '500',
    color: COLORS.primary,
  },
  content: {
    padding: 16,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 8,
  },
  description: {
    fontSize: 14,
    color: COLORS.textLight,
    lineHeight: 20,
  },
});