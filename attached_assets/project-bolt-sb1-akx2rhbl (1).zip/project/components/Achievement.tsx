import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Trophy } from 'lucide-react-native';
import { COLORS } from '@/constants/colors';

interface AchievementProps {
  title: string;
  description: string;
  level: 'bronze' | 'silver' | 'gold' | 'platinum';
  unlocked: boolean;
  progress?: number; // 0 to 1
}

export default function Achievement({
  title,
  description,
  level,
  unlocked,
  progress = 0,
}: AchievementProps) {
  const getLevelColor = () => {
    switch (level) {
      case 'bronze':
        return '#CD7F32';
      case 'silver':
        return '#C0C0C0';
      case 'gold':
        return '#FFD700';
      case 'platinum':
        return '#E5E4E2';
    }
  };
  
  const getLevelName = () => {
    switch (level) {
      case 'bronze':
        return 'Bronze';
      case 'silver':
        return 'Prata';
      case 'gold':
        return 'Ouro';
      case 'platinum':
        return 'Platina';
    }
  };
  
  return (
    <View style={[styles.container, !unlocked && styles.lockedContainer]}>
      <View
        style={[
          styles.iconContainer,
          { backgroundColor: unlocked ? getLevelColor() : COLORS.lightGray },
        ]}
      >
        <Trophy
          size={24}
          color={unlocked ? COLORS.white : COLORS.gray}
        />
      </View>
      
      <View style={styles.content}>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.description}>{description}</Text>
        
        <View style={styles.footer}>
          <Text style={[styles.level, { color: unlocked ? getLevelColor() : COLORS.gray }]}>
            {getLevelName()}
          </Text>
          
          {!unlocked && progress > 0 && (
            <View style={styles.progressContainer}>
              <View
                style={[
                  styles.progressBar,
                  { width: `${progress * 100}%` },
                ]}
              />
              <Text style={styles.progressText}>
                {Math.round(progress * 100)}%
              </Text>
            </View>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: COLORS.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  lockedContainer: {
    opacity: 0.7,
  },
  iconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    color: COLORS.textLight,
    marginBottom: 8,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  level: {
    fontSize: 14,
    fontWeight: '600',
  },
  progressContainer: {
    flex: 1,
    height: 6,
    backgroundColor: COLORS.lightGray,
    borderRadius: 3,
    marginLeft: 12,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressBar: {
    height: '100%',
    backgroundColor: COLORS.primary,
  },
  progressText: {
    fontSize: 10,
    color: COLORS.text,
    marginLeft: 6,
  },
});