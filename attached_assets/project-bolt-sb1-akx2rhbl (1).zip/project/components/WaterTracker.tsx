import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Droplets, Plus, Minus } from 'lucide-react-native';
import { COLORS } from '@/constants/colors';

interface WaterTrackerProps {
  currentML: number;
  goalML: number;
  onAdd: (amount: number) => void;
  onSubtract: (amount: number) => void;
}

export default function WaterTracker({
  currentML,
  goalML,
  onAdd,
  onSubtract,
}: WaterTrackerProps) {
  // Calculate progress percentage (capped at 100%)
  const progress = Math.min(currentML / goalML, 1);
  
  // Water levels in ML for quick add buttons
  const waterLevels = [100, 250, 500];
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Droplets size={24} color={COLORS.primary} />
        <Text style={styles.title}>Consumo de Água</Text>
      </View>
      
      <View style={styles.progressContainer}>
        <View style={styles.progressBarContainer}>
          <View style={[styles.progressBar, { height: `${progress * 100}%` }]} />
        </View>
        
        <View style={styles.statsContainer}>
          <Text style={styles.currentText}>{currentML}ml</Text>
          <View style={styles.divider} />
          <Text style={styles.goalText}>Meta: {goalML}ml</Text>
          <Text style={styles.percentageText}>
            {Math.round(progress * 100)}%
          </Text>
        </View>
      </View>
      
      <View style={styles.controlsContainer}>
        <Text style={styles.addWaterLabel}>Adicionar água:</Text>
        <View style={styles.buttonsContainer}>
          {waterLevels.map((ml) => (
            <TouchableOpacity
              key={ml}
              style={styles.amountButton}
              onPress={() => onAdd(ml)}
            >
              <Text style={styles.amountText}>{ml}ml</Text>
            </TouchableOpacity>
          ))}
        </View>
        
        <View style={styles.adjustContainer}>
          <TouchableOpacity
            style={styles.adjustButton}
            onPress={() => onSubtract(100)}
          >
            <Minus size={20} color={COLORS.text} />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.adjustButton}
            onPress={() => onAdd(100)}
          >
            <Plus size={20} color={COLORS.text} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    shadowColor: COLORS.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginLeft: 8,
  },
  progressContainer: {
    flexDirection: 'row',
    height: 150,
    marginBottom: 16,
  },
  progressBarContainer: {
    width: 60,
    height: '100%',
    backgroundColor: COLORS.lightGray,
    borderRadius: 8,
    overflow: 'hidden',
    justifyContent: 'flex-end',
  },
  progressBar: {
    width: '100%',
    backgroundColor: COLORS.secondary,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
  },
  statsContainer: {
    flex: 1,
    marginLeft: 16,
    justifyContent: 'center',
  },
  currentText: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.secondary,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.lightGray,
    marginVertical: 8,
  },
  goalText: {
    fontSize: 16,
    color: COLORS.textLight,
  },
  percentageText: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginTop: 8,
  },
  controlsContainer: {
    marginTop: 8,
  },
  addWaterLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: COLORS.text,
    marginBottom: 8,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  amountButton: {
    backgroundColor: COLORS.secondaryLight,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    marginHorizontal: 4,
  },
  amountText: {
    color: COLORS.text,
    fontWeight: '500',
  },
  adjustContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  adjustButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.lightGray,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 8,
  },
});