import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { CircleCheck as CheckCircle2, Circle } from 'lucide-react-native';
import { COLORS } from '@/constants/colors';

interface ChallengeCardProps {
  title: string;
  description: string;
  completed: boolean;
  type: 'home' | 'gym';
  onPress: () => void;
  locked?: boolean;
}

export default function ChallengeCard({
  title,
  description,
  completed,
  type,
  onPress,
  locked = false,
}: ChallengeCardProps) {
  return (
    <TouchableOpacity
      style={[
        styles.container,
        completed && styles.completedContainer,
        locked && styles.lockedContainer,
      ]}
      onPress={onPress}
      disabled={locked}
    >
      <View style={styles.typeIndicator}>
        <Text style={styles.typeText}>
          {type === 'home' ? 'Casa' : 'Academia'}
        </Text>
      </View>
      
      <View style={styles.content}>
        <Text style={[styles.title, completed && styles.completedText]}>
          {title}
        </Text>
        <Text style={[styles.description, completed && styles.completedText]}>
          {description}
        </Text>
      </View>
      
      <View style={styles.statusContainer}>
        {locked ? (
          <View style={styles.lockedBadge}>
            <Text style={styles.lockedText}>PRO</Text>
          </View>
        ) : completed ? (
          <CheckCircle2 size={24} color={COLORS.success} />
        ) : (
          <Circle size={24} color={COLORS.primary} />
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: COLORS.black,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  completedContainer: {
    backgroundColor: COLORS.lightGray,
  },
  lockedContainer: {
    opacity: 0.7,
  },
  typeIndicator: {
    backgroundColor: COLORS.primaryLight,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    marginRight: 12,
  },
  typeText: {
    color: COLORS.primary,
    fontWeight: '600',
    fontSize: 12,
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    color: COLORS.textLight,
  },
  completedText: {
    textDecorationLine: 'line-through',
  },
  statusContainer: {
    marginLeft: 12,
  },
  lockedBadge: {
    backgroundColor: COLORS.accent,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  lockedText: {
    color: COLORS.white,
    fontWeight: '600',
    fontSize: 12,
  },
});